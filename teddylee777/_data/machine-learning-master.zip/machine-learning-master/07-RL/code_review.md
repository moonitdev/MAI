코드 설명
<https://youtu.be/A-GAQdpdddI>
